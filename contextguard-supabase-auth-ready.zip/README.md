# ContextGuard — Burgundy Edition

A responsive ContextGuard knowledge-operations dashboard built with React + Vite and Supabase. Includes a burgundy visual theme, persistent light/dark mode, authentication, document CRUD/search/filter/export, activity feed, profile settings, analytics, and a heuristic conflict scan.

## Features
- Responsive dashboard, knowledge library, conflict center, analytics, profile and appearance settings.
- Add/edit/archive-status/delete documents; filter by category and status; search title/content/category/source; export JSON.
- Heuristic consistency scan that flags shared-topic documents with different numeric day deadlines or substantial shared terminology. This is a review aid, not an AI/legal determination.
- Supabase email/password sign-in and signup.
- Supabase Postgres tables with row-level security so users only access their own data.
- Persistent light/dark theme in browser local storage.
- Vercel SPA rewrite configuration.
- Preview/demo mode with sample records when Supabase environment variables are not set.

## Run locally
Requires Node.js 18+. The included `.env.local` is prefilled with this project’s URL and its browser-safe publishable key. Keep it out of source control (it is gitignored); configure the same variables in Vercel separately.

```bash
npm install
cp .env.example .env.local
# Edit .env.local with your Supabase project URL and anon/public key
npm run dev
```

Without Supabase values, the site runs in demo mode. Data edits stay in browser memory and reset on refresh. With Supabase connected, authentication and records persist.

## Set up the database
The `supabase/schema.sql` defines the `profiles`, `documents`, `conflicts`, and `activity` tables with Row Level Security and per-user ownership policies. It has already been applied to the connected Supabase project for this package. If you deploy to a different Supabase project, open **SQL Editor** and run the full `supabase/schema.sql`.
4. In **Project Settings → API**, copy the Project URL and publishable (browser-safe) key.
5. Put them in `.env.local` (the supplied file is already configured for the connected project; replace the values only if you use another project):

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
```

6. For production, configure the same two variables in Vercel → Project → Settings → Environment Variables. Redeploy after adding them.
7. In Supabase Authentication settings, configure your Site URL and redirect URLs to include your local development URL and deployed Vercel domain. If email confirmation is enabled, users must confirm signup before signing in.

**Security:** Use only the Supabase anon/public key in the frontend. Never put a Supabase service-role/secret key in a Vite variable or client code. The SQL schema enables RLS and restricts each user's rows by `auth.uid()`.

## Deploy to Vercel
1. Push this folder to a GitHub repository.
2. In Vercel, import that repository.
3. Framework preset: **Vite**. Build command: `npm run build`. Output directory: `dist`.
4. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` to Environment Variables for Production (and Preview if desired).
5. Deploy. `vercel.json` routes client-side URLs back to `index.html`.

## Database tables
- `profiles`: name and team preferences.
- `documents`: content, category, source, status, authority, timestamps.
- `conflicts`: candidate conflicts and resolution state.
- `activity`: recent user actions.

## Notes / limitations
- The scan is deterministic keyword/deadline heuristics. It does not call an LLM or guarantee detection of all contradictions.
- Integrations with Notion, Google Drive, Slack and Confluence are represented as document source labels; OAuth ingestion connectors are not configured in this starter.
- Document uploads are currently via paste/type and JSON export; storage/file import can be added later.
