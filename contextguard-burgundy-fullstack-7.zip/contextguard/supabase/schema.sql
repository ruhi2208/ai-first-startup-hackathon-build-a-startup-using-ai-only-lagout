-- Run this file in Supabase Dashboard → SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  team text not null default 'Operations',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  body text not null default '',
  category text not null default 'General',
  source text not null default 'Manual',
  status text not null default 'Active' check (status in ('Active','Needs review','Archived')),
  authority text not null default 'Standard' check (authority in ('Standard','Authoritative')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.conflicts (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  document_a uuid not null references public.documents(id) on delete cascade,
  document_b uuid not null references public.documents(id) on delete cascade,
  title text not null,
  details text not null default '',
  severity text not null default 'Medium' check (severity in ('Low','Medium','High')),
  status text not null default 'Open' check (status in ('Open','Resolved','Dismissed')),
  created_at timestamptz not null default now(),
  resolved_at timestamptz,
  unique(document_a, document_b)
);
create table if not exists public.activity (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  action text not null,
  target text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists documents_owner_updated_idx on public.documents(owner_id, updated_at desc);
create index if not exists conflicts_owner_status_idx on public.conflicts(owner_id, status);
create index if not exists activity_owner_created_idx on public.activity(owner_id, created_at desc);

alter table public.profiles enable row level security;
alter table public.documents enable row level security;
alter table public.conflicts enable row level security;
alter table public.activity enable row level security;

drop policy if exists "profile select own" on public.profiles;
create policy "profile select own" on public.profiles for select using (auth.uid() = id);
drop policy if exists "profile insert own" on public.profiles;
create policy "profile insert own" on public.profiles for insert with check (auth.uid() = id);
drop policy if exists "profile update own" on public.profiles;
create policy "profile update own" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);
drop policy if exists "documents own all" on public.documents;
create policy "documents own all" on public.documents for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
drop policy if exists "conflicts own all" on public.conflicts;
create policy "conflicts own all" on public.conflicts for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
drop policy if exists "activity own all" on public.activity;
create policy "activity own all" on public.activity for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, full_name) values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name','')) on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
