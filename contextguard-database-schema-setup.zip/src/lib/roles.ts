import "server-only";
import { redirect, notFound } from "next/navigation";
import { db } from "@/db";
import { memberships, organizations } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";

export type OrgRole = "owner" | "admin" | "member" | "viewer";

export async function getMembership(orgId: string, userId: string) {
  const rows = await db
    .select()
    .from(memberships)
    .where(and(eq(memberships.orgId, orgId), eq(memberships.userId, userId)))
    .limit(1);
  return rows[0] ?? null;
}

export async function requireMembership(orgId: string) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const rows = await db
    .select({
      role: memberships.role,
      orgId: organizations.id,
      orgName: organizations.name,
    })
    .from(memberships)
    .innerJoin(organizations, eq(memberships.orgId, organizations.id))
    .where(and(eq(memberships.orgId, orgId), eq(memberships.userId, user.id)))
    .limit(1);

  const row = rows[0];
  if (!row) notFound();

  return { user, role: row.role as OrgRole, org: { id: row.orgId, name: row.orgName } };
}

export function canManage(role: OrgRole | undefined | null) {
  return role === "owner" || role === "admin";
}

export function canWrite(role: OrgRole | undefined | null) {
  return role === "owner" || role === "admin" || role === "member";
}
