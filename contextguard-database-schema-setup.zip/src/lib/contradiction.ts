// Lightweight, dependency-free contradiction detection heuristic.
// Splits documents into paragraph-sized chunks and compares new chunks
// against existing chunks in the same workspace, flagging pairs that talk
// about the same topic but disagree on a number or use opposing language.

const STOPWORDS = new Set(
  [
    "the", "a", "an", "and", "or", "but", "if", "then", "else", "of", "to", "in", "on",
    "for", "with", "as", "by", "at", "from", "is", "are", "was", "were", "be", "been",
    "being", "this", "that", "these", "those", "it", "its", "we", "you", "they", "he",
    "she", "i", "our", "your", "their", "his", "her", "will", "shall", "can", "could",
    "would", "should", "must", "may", "might", "not", "no", "do", "does", "did", "have",
    "has", "had", "than", "so", "such", "into", "about", "per", "all", "any", "each",
    "which", "who", "whom", "there", "here", "also", "only", "up", "out", "over",
    "under", "again", "further", "once", "both", "other", "same", "more", "most",
  ].map((w) => w),
);

const ANTONYM_PAIRS: [string, string][] = [
  ["must", "optional"],
  ["mandatory", "optional"],
  ["required", "optional"],
  ["required", "voluntary"],
  ["allowed", "prohibited"],
  ["permitted", "prohibited"],
  ["allowed", "forbidden"],
  ["enabled", "disabled"],
  ["include", "exclude"],
  ["included", "excluded"],
  ["increase", "decrease"],
  ["increased", "decreased"],
  ["before", "after"],
  ["always", "never"],
  ["can", "cannot"],
  ["true", "false"],
  ["yes", "no"],
  ["approved", "rejected"],
  ["active", "inactive"],
  ["valid", "invalid"],
  ["public", "private"],
  ["free", "paid"],
  ["remote", "onsite"],
  ["unlimited", "limited"],
];

export type ChunkRecord = {
  id: string;
  documentId: string;
  content: string;
};

export type ContradictionMatch = {
  score: number;
  severity: "low" | "medium" | "high" | "critical";
  reason: string;
  keyword: string;
  a: ChunkRecord;
  b: ChunkRecord;
};

function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9.%$\s]/g, " ")
    .split(/\s+/)
    .filter(Boolean);
}

function significantWords(tokens: string[]): Set<string> {
  return new Set(tokens.filter((t) => t.length > 3 && !STOPWORDS.has(t) && !/^\d+$/.test(t)));
}

function extractNumbers(text: string): string[] {
  const matches = text.match(/\$?\d[\d,]*(\.\d+)?%?/g);
  return matches ? matches.map((m) => m.replace(/,/g, "")) : [];
}

export function chunkText(content: string): string[] {
  const paragraphs = content
    .split(/\n\s*\n/)
    .map((p) => p.trim())
    .filter((p) => p.length > 0);

  const chunks: string[] = [];
  for (const para of paragraphs) {
    if (para.length <= 600) {
      chunks.push(para);
    } else {
      // Split long paragraphs into sentence groups.
      const sentences = para.split(/(?<=[.!?])\s+/);
      let buffer = "";
      for (const sentence of sentences) {
        if ((buffer + " " + sentence).length > 600 && buffer) {
          chunks.push(buffer.trim());
          buffer = sentence;
        } else {
          buffer = buffer ? `${buffer} ${sentence}` : sentence;
        }
      }
      if (buffer.trim()) chunks.push(buffer.trim());
    }
  }
  return chunks.length > 0 ? chunks : [content.trim()].filter(Boolean);
}

export function jaccard(a: Set<string>, b: Set<string>): number {
  if (a.size === 0 || b.size === 0) return 0;
  let intersection = 0;
  for (const word of a) {
    if (b.has(word)) intersection += 1;
  }
  const union = a.size + b.size - intersection;
  return union === 0 ? 0 : intersection / union;
}

export function findContradiction(a: ChunkRecord, b: ChunkRecord): ContradictionMatch | null {
  if (a.documentId === b.documentId) return null;

  const tokensA = tokenize(a.content);
  const tokensB = tokenize(b.content);
  const wordsA = significantWords(tokensA);
  const wordsB = significantWords(tokensB);

  const shared: string[] = [];
  for (const w of wordsA) {
    if (wordsB.has(w)) shared.push(w);
  }
  const similarity = jaccard(wordsA, wordsB);

  // Require meaningful topical overlap before flagging anything.
  if (similarity < 0.12 || shared.length < 2) return null;

  const keyword = shared.sort((x, y) => y.length - x.length)[0] ?? shared[0];

  // 1) Numeric mismatch about the same topic.
  const numsA = extractNumbers(a.content);
  const numsB = extractNumbers(b.content);
  if (numsA.length > 0 && numsB.length > 0) {
    const setA = new Set(numsA);
    const setB = new Set(numsB);
    const differing = [...setA].some((n) => !setB.has(n)) && [...setB].some((n) => !setA.has(n));
    if (differing) {
      const severity = similarity > 0.35 ? "high" : "medium";
      return {
        score: similarity,
        severity,
        reason: `Both passages discuss "${keyword}" but cite different figures (${numsA.join(", ")} vs ${numsB.join(", ")}).`,
        keyword,
        a,
        b,
      };
    }
  }

  // 2) Opposing / antonym language about the same topic.
  for (const [left, right] of ANTONYM_PAIRS) {
    const aHasLeft = tokensA.includes(left);
    const aHasRight = tokensA.includes(right);
    const bHasLeft = tokensB.includes(left);
    const bHasRight = tokensB.includes(right);
    if ((aHasLeft && bHasRight) || (aHasRight && bHasLeft)) {
      const severity = similarity > 0.3 ? "critical" : "high";
      return {
        score: similarity,
        severity,
        reason: `Passages about "${keyword}" use opposing terms ("${left}" vs "${right}").`,
        keyword,
        a,
        b,
      };
    }
  }

  // 3) Direct negation: one passage negates a shared keyword, the other doesn't.
  const negationWindow = (tokens: string[], word: string) => {
    const idx = tokens.indexOf(word);
    if (idx === -1) return false;
    const windowTokens = tokens.slice(Math.max(0, idx - 3), idx);
    return windowTokens.includes("not") || windowTokens.includes("no") || windowTokens.includes("never");
  };

  for (const word of shared) {
    const negatedInA = negationWindow(tokensA, word);
    const negatedInB = negationWindow(tokensB, word);
    if (negatedInA !== negatedInB && similarity > 0.2) {
      return {
        score: similarity,
        severity: similarity > 0.4 ? "high" : "medium",
        reason: `One passage negates "${word}" while the other affirms it.`,
        keyword: word,
        a,
        b,
      };
    }
  }

  return null;
}

export function findAllContradictions(
  newChunks: ChunkRecord[],
  existingChunks: ChunkRecord[],
): ContradictionMatch[] {
  const matches: ContradictionMatch[] = [];
  for (const nc of newChunks) {
    for (const ec of existingChunks) {
      const match = findContradiction(nc, ec);
      if (match) matches.push(match);
    }
  }
  return matches;
}
