import "server-only";
import { db } from "@/db";
import { auditLog } from "@/db/schema";

export async function writeAudit(params: {
  orgId: string;
  actorId: string | null;
  action: "INSERT" | "UPDATE" | "DELETE";
  entityType: string;
  entityId: string | null;
  oldData?: unknown;
  newData?: unknown;
}) {
  await db.insert(auditLog).values({
    orgId: params.orgId,
    actorId: params.actorId,
    action: params.action,
    entityType: params.entityType,
    entityId: params.entityId,
    oldData: params.oldData ?? null,
    newData: params.newData ?? null,
  });
}
