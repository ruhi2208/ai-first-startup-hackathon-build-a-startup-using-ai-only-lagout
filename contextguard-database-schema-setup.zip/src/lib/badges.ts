export const severityClasses: Record<string, string> = {
  low: "border-slate-500/30 bg-slate-500/10 text-slate-300",
  medium: "border-amber-500/30 bg-amber-500/10 text-amber-300",
  high: "border-orange-500/30 bg-orange-500/10 text-orange-300",
  critical: "border-red-500/30 bg-red-500/10 text-red-300",
};

export const statusClasses: Record<string, string> = {
  open: "border-indigo-500/30 bg-indigo-500/10 text-indigo-300",
  in_review: "border-amber-500/30 bg-amber-500/10 text-amber-300",
  resolved: "border-emerald-500/30 bg-emerald-500/10 text-emerald-300",
  dismissed: "border-slate-500/30 bg-slate-500/10 text-slate-400",
};

export const documentStatusClasses: Record<string, string> = {
  uploaded: "border-slate-500/30 bg-slate-500/10 text-slate-300",
  processing: "border-amber-500/30 bg-amber-500/10 text-amber-300",
  ready: "border-emerald-500/30 bg-emerald-500/10 text-emerald-300",
  failed: "border-red-500/30 bg-red-500/10 text-red-300",
};

export function formatLabel(value: string) {
  return value
    .split("_")
    .map((w) => w[0]?.toUpperCase() + w.slice(1))
    .join(" ");
}
