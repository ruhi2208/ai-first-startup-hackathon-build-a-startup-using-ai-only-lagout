import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";
import { ShieldLogo } from "@/components/ShieldLogo";

export const dynamic = "force-dynamic";

const FEATURES = [
  {
    title: "Contradiction detection",
    desc: "ContextGuard scans every new document against your workspace and flags passages that disagree on numbers, policies, or language.",
    icon: "⚡",
  },
  {
    title: "Evidence-backed conflicts",
    desc: "Every conflict links back to the exact excerpts that contradict each other, so reviewers can see both sides instantly.",
    icon: "🔍",
  },
  {
    title: "Review workflow",
    desc: "Assign conflicts, discuss them in threaded comments, and resolve or dismiss with a recorded rationale.",
    icon: "✅",
  },
  {
    title: "Tamper-resistant audit log",
    desc: "Every create, update, and resolution is appended to an immutable audit trail scoped to your workspace.",
    icon: "🛡️",
  },
  {
    title: "Role-based workspaces",
    desc: "Owners, admins, members, and viewers each get the right level of access across your organization's knowledge base.",
    icon: "👥",
  },
  {
    title: "Unified search",
    desc: "Search documents and conflicts together to find out what your company actually believes right now.",
    icon: "🧭",
  },
];

export default async function HomePage() {
  const user = await getCurrentUser();

  return (
    <main className="min-h-screen bg-slate-950 text-white">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <Link href="/" className="flex items-center gap-2">
          <ShieldLogo className="h-7 w-7" />
          <span className="text-lg font-semibold tracking-tight">ContextGuard</span>
        </Link>
        <nav className="flex items-center gap-3">
          {user ? (
            <Link
              href="/dashboard"
              className="rounded-lg bg-indigo-500 px-4 py-2 text-sm font-semibold transition hover:bg-indigo-400"
            >
              Go to dashboard
            </Link>
          ) : (
            <>
              <Link href="/login" className="rounded-lg px-4 py-2 text-sm font-medium text-slate-300 hover:text-white">
                Sign in
              </Link>
              <Link
                href="/signup"
                className="rounded-lg bg-indigo-500 px-4 py-2 text-sm font-semibold transition hover:bg-indigo-400"
              >
                Get started
              </Link>
            </>
          )}
        </nav>
      </header>

      <section className="relative overflow-hidden px-6 pb-24 pt-16 text-center">
        <div
          aria-hidden
          className="pointer-events-none absolute left-1/2 top-0 h-[560px] w-[900px] -translate-x-1/2 rounded-full bg-indigo-600/20 blur-3xl"
        />
        <div className="relative mx-auto max-w-3xl">
          <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-medium text-indigo-300">
            Now detecting contradictions automatically
          </span>
          <h1 className="mt-6 text-4xl font-semibold leading-tight tracking-tight sm:text-6xl">
            Keep Company Knowledge <span className="text-indigo-400">in Context</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-base text-slate-400 sm:text-lg">
            ContextGuard ingests your policies, specs, and docs, finds where they contradict each
            other, and gives your team a workflow to resolve conflicts before they cause real
            damage — all with a full audit trail.
          </p>
          <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link
              href={user ? "/dashboard" : "/signup"}
              className="w-full rounded-lg bg-indigo-500 px-6 py-3 text-sm font-semibold text-white transition hover:bg-indigo-400 sm:w-auto"
            >
              {user ? "Open your workspace" : "Start detecting conflicts"}
            </Link>
            <Link
              href={user ? "/dashboard" : "/login"}
              className="w-full rounded-lg border border-white/15 bg-white/5 px-6 py-3 text-sm font-semibold text-white transition hover:bg-white/10 sm:w-auto"
            >
              {user ? "View conflicts" : "Sign in"}
            </Link>
          </div>
        </div>

        <div className="relative mx-auto mt-16 max-w-4xl rounded-2xl border border-white/10 bg-white/[0.03] p-3 shadow-2xl backdrop-blur">
          <div className="flex items-center gap-2 border-b border-white/5 px-3 pb-3">
            <span className="h-3 w-3 rounded-full bg-red-400/70" />
            <span className="h-3 w-3 rounded-full bg-yellow-400/70" />
            <span className="h-3 w-3 rounded-full bg-green-400/70" />
            <div className="ml-4 flex-1 rounded-md bg-slate-900/80 px-3 py-1 text-left text-xs text-slate-500">
              Search documents and conflicts
            </div>
          </div>
          <div className="grid grid-cols-1 gap-3 p-4 text-left sm:grid-cols-3">
            <div className="rounded-xl border border-red-500/20 bg-red-500/5 p-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-red-300">Critical</p>
              <p className="mt-2 text-sm font-medium text-white">Refund window: 14 vs 30 days</p>
              <p className="mt-1 text-xs text-slate-400">Refund-Policy.pdf vs Terms-2024.docx</p>
            </div>
            <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-amber-300">High</p>
              <p className="mt-2 text-sm font-medium text-white">Remote work: allowed vs prohibited</p>
              <p className="mt-1 text-xs text-slate-400">HR-Handbook.md vs Eng-Guidelines.md</p>
            </div>
            <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-emerald-300">Resolved</p>
              <p className="mt-2 text-sm font-medium text-white">Pricing: $49 vs $59 per seat</p>
              <p className="mt-1 text-xs text-slate-400">Pricing-Sheet.csv vs Sales-Deck.pdf</p>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 pb-24">
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <div
              key={f.title}
              className="rounded-2xl border border-white/10 bg-white/[0.02] p-6 transition hover:bg-white/[0.04]"
            >
              <div className="text-2xl">{f.icon}</div>
              <h3 className="mt-4 text-base font-semibold text-white">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-400">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="border-t border-white/10 px-6 py-16 text-center">
        <h2 className="text-2xl font-semibold text-white sm:text-3xl">
          Stop shipping contradictory docs.
        </h2>
        <p className="mx-auto mt-3 max-w-xl text-sm text-slate-400">
          Create a free workspace, drop in your first two documents, and watch ContextGuard surface
          the conflicts automatically.
        </p>
        <Link
          href={user ? "/dashboard" : "/signup"}
          className="mt-8 inline-block rounded-lg bg-indigo-500 px-6 py-3 text-sm font-semibold text-white transition hover:bg-indigo-400"
        >
          {user ? "Open your workspace" : "Create your workspace"}
        </Link>
      </section>

      <footer className="border-t border-white/10 px-6 py-8 text-center text-xs text-slate-500">
        © {new Date().getFullYear()} ContextGuard. Built with Next.js, Drizzle, and PostgreSQL.
      </footer>
    </main>
  );
}
