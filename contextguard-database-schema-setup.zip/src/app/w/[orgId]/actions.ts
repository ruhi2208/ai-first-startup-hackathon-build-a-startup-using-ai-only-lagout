"use server";

import { redirect } from "next/navigation";
import { and, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import {
  conflictComments,
  conflictEvidence,
  conflicts,
  documentChunks,
  documents,
  memberships,
  users,
} from "@/db/schema";
import { requireMembership } from "@/lib/roles";
import { writeAudit } from "@/lib/audit";
import { chunkText, findAllContradictions, type ChunkRecord } from "@/lib/contradiction";

function fail(path: string, message: string): never {
  redirect(`${path}?error=${encodeURIComponent(message)}`);
}

// ---------------------------------------------------------------------
// DOCUMENTS
// ---------------------------------------------------------------------
export async function uploadDocumentAction(formData: FormData) {
  const orgId = String(formData.get("orgId") || "");
  const { user, role } = await requireMembership(orgId);
  if (!(role === "owner" || role === "admin" || role === "member")) {
    fail(`/w/${orgId}/documents`, "You don't have permission to add documents.");
  }

  const title = String(formData.get("title") || "").trim();
  let content = String(formData.get("content") || "").trim();
  const file = formData.get("file");

  if (file instanceof File && file.size > 0) {
    content = (await file.text()).trim();
  }

  if (!title) fail(`/w/${orgId}/documents`, "Title is required.");
  if (!content) fail(`/w/${orgId}/documents`, "Document content (text or file) is required.");
  if (content.length > 200_000) fail(`/w/${orgId}/documents`, "Document is too large (max 200,000 characters).");

  const [doc] = await db
    .insert(documents)
    .values({
      orgId,
      title,
      source: file instanceof File && file.size > 0 ? "upload" : "paste",
      content,
      mimeType: file instanceof File ? file.type || "text/plain" : "text/plain",
      sizeBytes: Buffer.byteLength(content, "utf8"),
      status: "processing",
      uploadedBy: user.id,
    })
    .returning();

  await writeAudit({
    orgId,
    actorId: user.id,
    action: "INSERT",
    entityType: "documents",
    entityId: doc.id,
    newData: doc,
  });

  try {
    const pieces = chunkText(content);
    const insertedChunks = await db
      .insert(documentChunks)
      .values(
        pieces.map((piece, idx) => ({
          documentId: doc.id,
          orgId,
          chunkIndex: idx,
          content: piece,
        })),
      )
      .returning();

    const newChunkRecords: ChunkRecord[] = insertedChunks.map((c) => ({
      id: c.id,
      documentId: c.documentId,
      content: c.content,
    }));

    const existingRows = await db
      .select({
        id: documentChunks.id,
        documentId: documentChunks.documentId,
        content: documentChunks.content,
      })
      .from(documentChunks)
      .where(and(eq(documentChunks.orgId, orgId), ne(documentChunks.documentId, doc.id)));

    const matches = findAllContradictions(newChunkRecords, existingRows);

    // De-duplicate: keep the strongest match per (other document, keyword) pair.
    const bestByKey = new Map<string, (typeof matches)[number]>();
    for (const m of matches) {
      const key = `${m.b.documentId}:${m.keyword}`;
      const current = bestByKey.get(key);
      if (!current || m.score > current.score) bestByKey.set(key, m);
    }
    const topMatches = [...bestByKey.values()].sort((a, b) => b.score - a.score).slice(0, 8);

    for (const match of topMatches) {
      const otherDoc = await db
        .select({ id: documents.id, title: documents.title })
        .from(documents)
        .where(eq(documents.id, match.b.documentId))
        .limit(1);
      const otherTitle = otherDoc[0]?.title ?? "another document";

      const [conflict] = await db
        .insert(conflicts)
        .values({
          orgId,
          title: `"${match.keyword}" conflict between "${doc.title}" and "${otherTitle}"`,
          summary: match.reason,
          severity: match.severity,
          status: "open",
        })
        .returning();

      await writeAudit({
        orgId,
        actorId: user.id,
        action: "INSERT",
        entityType: "conflicts",
        entityId: conflict.id,
        newData: conflict,
      });

      const evidenceRows = await db
        .insert(conflictEvidence)
        .values([
          {
            conflictId: conflict.id,
            orgId,
            documentId: doc.id,
            chunkId: match.a.id,
            excerpt: match.a.content,
          },
          {
            conflictId: conflict.id,
            orgId,
            documentId: match.b.documentId,
            chunkId: match.b.id,
            excerpt: match.b.content,
          },
        ])
        .returning();

      for (const ev of evidenceRows) {
        await writeAudit({
          orgId,
          actorId: user.id,
          action: "INSERT",
          entityType: "conflict_evidence",
          entityId: ev.id,
          newData: ev,
        });
      }
    }

    const [updatedDoc] = await db
      .update(documents)
      .set({ status: "ready", updatedAt: new Date() })
      .where(eq(documents.id, doc.id))
      .returning();

    await writeAudit({
      orgId,
      actorId: user.id,
      action: "UPDATE",
      entityType: "documents",
      entityId: doc.id,
      oldData: doc,
      newData: updatedDoc,
    });
  } catch (err) {
    await db
      .update(documents)
      .set({ status: "failed", errorMessage: err instanceof Error ? err.message : "Processing failed" })
      .where(eq(documents.id, doc.id));
  }

  redirect(`/w/${orgId}/documents/${doc.id}`);
}

export async function deleteDocumentAction(formData: FormData) {
  const orgId = String(formData.get("orgId") || "");
  const documentId = String(formData.get("documentId") || "");
  const { user, role } = await requireMembership(orgId);
  if (!(role === "owner" || role === "admin")) {
    fail(`/w/${orgId}/documents`, "Only owners and admins can delete documents.");
  }

  const [existing] = await db.select().from(documents).where(eq(documents.id, documentId)).limit(1);
  if (existing) {
    await db.delete(documents).where(eq(documents.id, documentId));
    await writeAudit({
      orgId,
      actorId: user.id,
      action: "DELETE",
      entityType: "documents",
      entityId: documentId,
      oldData: existing,
    });
  }

  redirect(`/w/${orgId}/documents`);
}

// ---------------------------------------------------------------------
// CONFLICTS
// ---------------------------------------------------------------------
export async function updateConflictAction(formData: FormData) {
  const orgId = String(formData.get("orgId") || "");
  const conflictId = String(formData.get("conflictId") || "");
  const { user, role } = await requireMembership(orgId);
  if (!(role === "owner" || role === "admin" || role === "member")) {
    fail(`/w/${orgId}/conflicts/${conflictId}`, "You don't have permission to update conflicts.");
  }

  const status = String(formData.get("status") || "");
  const resolution = String(formData.get("resolution") || "").trim();
  const assignedTo = String(formData.get("assignedTo") || "");

  const [existing] = await db.select().from(conflicts).where(eq(conflicts.id, conflictId)).limit(1);
  if (!existing) fail(`/w/${orgId}/conflicts`, "Conflict not found.");

  const patch: Partial<typeof conflicts.$inferInsert> = {
    updatedAt: new Date(),
  };
  if (status) patch.status = status as (typeof conflicts.$inferInsert)["status"];
  if (resolution) patch.resolution = resolution;
  patch.assignedTo = assignedTo ? assignedTo : null;

  if (status === "resolved" && existing.status !== "resolved") {
    patch.resolvedAt = new Date();
    patch.resolvedBy = user.id;
  } else if (status && status !== "resolved") {
    patch.resolvedAt = null;
    patch.resolvedBy = null;
  }

  const [updated] = await db.update(conflicts).set(patch).where(eq(conflicts.id, conflictId)).returning();

  await writeAudit({
    orgId,
    actorId: user.id,
    action: "UPDATE",
    entityType: "conflicts",
    entityId: conflictId,
    oldData: existing,
    newData: updated,
  });

  redirect(`/w/${orgId}/conflicts/${conflictId}`);
}

export async function addCommentAction(formData: FormData) {
  const orgId = String(formData.get("orgId") || "");
  const conflictId = String(formData.get("conflictId") || "");
  const { user, role } = await requireMembership(orgId);
  if (!(role === "owner" || role === "admin" || role === "member")) {
    fail(`/w/${orgId}/conflicts/${conflictId}`, "You don't have permission to comment.");
  }

  const body = String(formData.get("body") || "").trim();
  if (!body) redirect(`/w/${orgId}/conflicts/${conflictId}`);

  const [comment] = await db
    .insert(conflictComments)
    .values({ conflictId, orgId, authorId: user.id, body })
    .returning();

  await writeAudit({
    orgId,
    actorId: user.id,
    action: "INSERT",
    entityType: "conflict_comments",
    entityId: comment.id,
    newData: comment,
  });

  redirect(`/w/${orgId}/conflicts/${conflictId}`);
}

// ---------------------------------------------------------------------
// MEMBERS
// ---------------------------------------------------------------------
export async function inviteMemberAction(formData: FormData) {
  const orgId = String(formData.get("orgId") || "");
  const { role } = await requireMembership(orgId);
  if (!(role === "owner" || role === "admin")) {
    fail(`/w/${orgId}/members`, "Only owners and admins can manage members.");
  }

  const email = String(formData.get("email") || "")
    .trim()
    .toLowerCase();
  const newRole = String(formData.get("role") || "member") as "owner" | "admin" | "member" | "viewer";

  const [targetUser] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (!targetUser) {
    fail(`/w/${orgId}/members`, `No ContextGuard account found for ${email}. Ask them to sign up first.`);
  }

  const [existing] = await db
    .select()
    .from(memberships)
    .where(and(eq(memberships.orgId, orgId), eq(memberships.userId, targetUser.id)))
    .limit(1);

  if (existing) {
    await db
      .update(memberships)
      .set({ role: newRole })
      .where(and(eq(memberships.orgId, orgId), eq(memberships.userId, targetUser.id)));
  } else {
    await db.insert(memberships).values({ orgId, userId: targetUser.id, role: newRole });
  }

  redirect(`/w/${orgId}/members`);
}

export async function changeMemberRoleAction(formData: FormData) {
  const orgId = String(formData.get("orgId") || "");
  const targetUserId = String(formData.get("userId") || "");
  const { role, user } = await requireMembership(orgId);
  if (!(role === "owner" || role === "admin")) {
    fail(`/w/${orgId}/members`, "Only owners and admins can manage members.");
  }

  const newRole = String(formData.get("role") || "member") as "owner" | "admin" | "member" | "viewer";

  if (targetUserId === user.id && newRole !== "owner") {
    const owners = await db
      .select()
      .from(memberships)
      .where(and(eq(memberships.orgId, orgId), eq(memberships.role, "owner")));
    if (owners.length <= 1) {
      fail(`/w/${orgId}/members`, "A workspace needs at least one owner.");
    }
  }

  await db
    .update(memberships)
    .set({ role: newRole })
    .where(and(eq(memberships.orgId, orgId), eq(memberships.userId, targetUserId)));

  redirect(`/w/${orgId}/members`);
}

export async function removeMemberAction(formData: FormData) {
  const orgId = String(formData.get("orgId") || "");
  const targetUserId = String(formData.get("userId") || "");
  const { role } = await requireMembership(orgId);
  if (!(role === "owner" || role === "admin")) {
    fail(`/w/${orgId}/members`, "Only owners and admins can manage members.");
  }

  const [target] = await db
    .select()
    .from(memberships)
    .where(and(eq(memberships.orgId, orgId), eq(memberships.userId, targetUserId)))
    .limit(1);

  if (target?.role === "owner") {
    const owners = await db
      .select()
      .from(memberships)
      .where(and(eq(memberships.orgId, orgId), eq(memberships.role, "owner")));
    if (owners.length <= 1) {
      fail(`/w/${orgId}/members`, "A workspace needs at least one owner.");
    }
  }

  await db
    .delete(memberships)
    .where(and(eq(memberships.orgId, orgId), eq(memberships.userId, targetUserId)));

  redirect(`/w/${orgId}/members`);
}
