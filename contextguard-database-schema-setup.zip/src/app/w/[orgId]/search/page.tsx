import Link from "next/link";
import { db } from "@/db";
import { conflicts, documents } from "@/db/schema";
import { and, eq, ilike, or, sql } from "drizzle-orm";
import { requireMembership } from "@/lib/roles";
import { severityClasses } from "@/lib/badges";

export const dynamic = "force-dynamic";

export default async function SearchPage({
  params,
  searchParams,
}: {
  params: Promise<{ orgId: string }>;
  searchParams: Promise<{ q?: string }>;
}) {
  const { orgId } = await params;
  await requireMembership(orgId);
  const { q } = await searchParams;
  const query = (q ?? "").trim();

  let matchedDocs: (typeof documents.$inferSelect)[] = [];
  let matchedConflicts: (typeof conflicts.$inferSelect)[] = [];

  if (query) {
    const like = `%${query}%`;
    [matchedDocs, matchedConflicts] = await Promise.all([
      db
        .select()
        .from(documents)
        .where(and(eq(documents.orgId, orgId), or(ilike(documents.title, like), ilike(documents.content, like)))),
      db
        .select()
        .from(conflicts)
        .where(
          and(
            eq(conflicts.orgId, orgId),
            or(ilike(conflicts.title, like), ilike(sql`coalesce(${conflicts.summary}, '')`, like)),
          ),
        ),
    ]);
  }

  return (
    <div className="space-y-8">
      <form action={`/w/${orgId}/search`} method="GET" className="max-w-lg">
        <input
          type="text"
          name="q"
          defaultValue={query}
          placeholder="Search documents and conflicts"
          className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2 text-sm text-white outline-none ring-indigo-500 placeholder:text-slate-500 focus:ring-2"
        />
      </form>

      {query ? (
        <>
          <section>
            <h2 className="text-sm font-semibold text-white">Documents ({matchedDocs.length})</h2>
            <div className="mt-3 space-y-2">
              {matchedDocs.map((d) => (
                <Link
                  key={d.id}
                  href={`/w/${orgId}/documents/${d.id}`}
                  className="block rounded-xl border border-white/10 bg-white/[0.02] p-3 transition hover:bg-white/[0.05]"
                >
                  <p className="text-sm font-medium text-white">{d.title}</p>
                </Link>
              ))}
              {matchedDocs.length === 0 ? <p className="text-sm text-slate-500">No documents found.</p> : null}
            </div>
          </section>

          <section>
            <h2 className="text-sm font-semibold text-white">Conflicts ({matchedConflicts.length})</h2>
            <div className="mt-3 space-y-2">
              {matchedConflicts.map((c) => (
                <Link
                  key={c.id}
                  href={`/w/${orgId}/conflicts/${c.id}`}
                  className="flex items-center justify-between rounded-xl border border-white/10 bg-white/[0.02] p-3 transition hover:bg-white/[0.05]"
                >
                  <span className="text-sm font-medium text-white">{c.title}</span>
                  <span className={`rounded-full border px-2 py-0.5 text-[10px] uppercase ${severityClasses[c.severity]}`}>
                    {c.severity}
                  </span>
                </Link>
              ))}
              {matchedConflicts.length === 0 ? <p className="text-sm text-slate-500">No conflicts found.</p> : null}
            </div>
          </section>
        </>
      ) : (
        <p className="text-sm text-slate-500">Type a search term above to look across this workspace.</p>
      )}
    </div>
  );
}
