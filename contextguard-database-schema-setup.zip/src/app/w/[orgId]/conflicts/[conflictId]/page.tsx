import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import {
  conflictComments,
  conflictEvidence,
  conflicts,
  documents,
  memberships,
  users,
} from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireMembership } from "@/lib/roles";
import { severityClasses, statusClasses, formatLabel } from "@/lib/badges";
import { addCommentAction, updateConflictAction } from "../../actions";

export const dynamic = "force-dynamic";

export default async function ConflictDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ orgId: string; conflictId: string }>;
  searchParams: Promise<{ error?: string }>;
}) {
  const { orgId, conflictId } = await params;
  const { role } = await requireMembership(orgId);
  const { error } = await searchParams;
  const canWrite = role === "owner" || role === "admin" || role === "member";

  const [conflict] = await db.select().from(conflicts).where(eq(conflicts.id, conflictId)).limit(1);
  if (!conflict || conflict.orgId !== orgId) notFound();

  const [evidence, comments, members] = await Promise.all([
    db
      .select({ evidence: conflictEvidence, document: documents })
      .from(conflictEvidence)
      .innerJoin(documents, eq(conflictEvidence.documentId, documents.id))
      .where(eq(conflictEvidence.conflictId, conflictId)),
    db
      .select({ comment: conflictComments, author: users })
      .from(conflictComments)
      .innerJoin(users, eq(conflictComments.authorId, users.id))
      .where(eq(conflictComments.conflictId, conflictId))
      .orderBy(conflictComments.createdAt),
    db
      .select({ userId: memberships.userId, role: memberships.role, email: users.email, fullName: users.fullName })
      .from(memberships)
      .innerJoin(users, eq(memberships.userId, users.id))
      .where(eq(memberships.orgId, orgId)),
  ]);

  const assignee = conflict.assignedTo ? members.find((m) => m.userId === conflict.assignedTo) : null;

  return (
    <div className="space-y-8">
      <div>
        <Link href={`/w/${orgId}/conflicts`} className="text-xs text-slate-500 hover:text-slate-300">
          ← Back to conflicts
        </Link>
        <div className="mt-1 flex flex-wrap items-center gap-2">
          <h1 className="text-xl font-semibold text-white">{conflict.title}</h1>
          <span className={`rounded-full border px-2 py-0.5 text-[11px] uppercase ${severityClasses[conflict.severity]}`}>
            {conflict.severity}
          </span>
          <span className={`rounded-full border px-2 py-0.5 text-[11px] ${statusClasses[conflict.status]}`}>
            {formatLabel(conflict.status)}
          </span>
        </div>
        {conflict.summary ? <p className="mt-2 text-sm text-slate-400">{conflict.summary}</p> : null}
        <p className="mt-2 text-xs text-slate-500">
          Detected {new Date(conflict.detectedAt).toLocaleString()}
          {assignee ? ` · Assigned to ${assignee.fullName ?? assignee.email}` : ""}
        </p>
        {conflict.status === "resolved" && conflict.resolution ? (
          <p className="mt-3 rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-sm text-emerald-300">
            Resolution: {conflict.resolution}
          </p>
        ) : null}
      </div>

      {error ? (
        <p className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</p>
      ) : null}

      <section>
        <h2 className="text-sm font-semibold text-white">Conflicting evidence</h2>
        <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2">
          {evidence.map((e) => (
            <div key={e.evidence.id} className="rounded-xl border border-white/10 bg-white/[0.02] p-4">
              <Link
                href={`/w/${orgId}/documents/${e.document.id}`}
                className="text-xs font-semibold uppercase tracking-wide text-indigo-400 hover:text-indigo-300"
              >
                {e.document.title}
              </Link>
              <p className="mt-2 whitespace-pre-wrap text-sm text-slate-300">{e.evidence.excerpt}</p>
            </div>
          ))}
        </div>
      </section>

      {canWrite ? (
        <section className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
          <h2 className="text-sm font-semibold text-white">Review &amp; resolve</h2>
          <form action={updateConflictAction} className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <input type="hidden" name="orgId" value={orgId} />
            <input type="hidden" name="conflictId" value={conflict.id} />
            <div>
              <label className="mb-1 block text-xs uppercase tracking-wide text-slate-500">Status</label>
              <select
                name="status"
                defaultValue={conflict.status}
                className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2 text-sm text-white outline-none ring-indigo-500 focus:ring-2"
              >
                <option value="open">Open</option>
                <option value="in_review">In review</option>
                <option value="resolved">Resolved</option>
                <option value="dismissed">Dismissed</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs uppercase tracking-wide text-slate-500">Assign to</label>
              <select
                name="assignedTo"
                defaultValue={conflict.assignedTo ?? ""}
                className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2 text-sm text-white outline-none ring-indigo-500 focus:ring-2"
              >
                <option value="">Unassigned</option>
                {members.map((m) => (
                  <option key={m.userId} value={m.userId}>
                    {m.fullName ?? m.email}
                  </option>
                ))}
              </select>
            </div>
            <div className="sm:col-span-2">
              <label className="mb-1 block text-xs uppercase tracking-wide text-slate-500">
                Resolution notes
              </label>
              <textarea
                name="resolution"
                rows={2}
                defaultValue={conflict.resolution ?? ""}
                placeholder="What was decided / which source is correct?"
                className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2 text-sm text-white outline-none ring-indigo-500 placeholder:text-slate-500 focus:ring-2"
              />
            </div>
            <div className="sm:col-span-2">
              <button
                type="submit"
                className="rounded-lg bg-indigo-500 px-4 py-2 text-sm font-semibold text-white transition hover:bg-indigo-400"
              >
                Save changes
              </button>
            </div>
          </form>
        </section>
      ) : null}

      <section>
        <h2 className="text-sm font-semibold text-white">Discussion</h2>
        <div className="mt-3 space-y-3">
          {comments.map((c) => (
            <div key={c.comment.id} className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-white">{c.author.fullName ?? c.author.email}</span>
                <span className="text-[11px] text-slate-500">{new Date(c.comment.createdAt).toLocaleString()}</span>
              </div>
              <p className="mt-1 text-sm text-slate-300">{c.comment.body}</p>
            </div>
          ))}
          {comments.length === 0 ? <p className="text-sm text-slate-500">No comments yet.</p> : null}
        </div>

        {canWrite ? (
          <form action={addCommentAction} className="mt-4 flex gap-2">
            <input type="hidden" name="orgId" value={orgId} />
            <input type="hidden" name="conflictId" value={conflict.id} />
            <input
              type="text"
              name="body"
              required
              placeholder="Add a comment..."
              className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2 text-sm text-white outline-none ring-indigo-500 placeholder:text-slate-500 focus:ring-2"
            />
            <button
              type="submit"
              className="shrink-0 rounded-lg bg-indigo-500 px-4 py-2 text-sm font-semibold text-white transition hover:bg-indigo-400"
            >
              Post
            </button>
          </form>
        ) : null}
      </section>
    </div>
  );
}
