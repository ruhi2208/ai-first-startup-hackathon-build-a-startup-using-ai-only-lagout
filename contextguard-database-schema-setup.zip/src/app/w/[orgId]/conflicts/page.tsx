import Link from "next/link";
import { db } from "@/db";
import { conflicts } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { requireMembership } from "@/lib/roles";
import { severityClasses, statusClasses, formatLabel } from "@/lib/badges";

export const dynamic = "force-dynamic";

const STATUS_OPTIONS = ["open", "in_review", "resolved", "dismissed"] as const;
const SEVERITY_OPTIONS = ["critical", "high", "medium", "low"] as const;

export default async function ConflictsPage({
  params,
  searchParams,
}: {
  params: Promise<{ orgId: string }>;
  searchParams: Promise<{ status?: string; severity?: string }>;
}) {
  const { orgId } = await params;
  await requireMembership(orgId);
  const { status, severity } = await searchParams;

  const conditions = [eq(conflicts.orgId, orgId)];
  if (status && (STATUS_OPTIONS as readonly string[]).includes(status)) {
    conditions.push(eq(conflicts.status, status as (typeof STATUS_OPTIONS)[number]));
  }
  if (severity && (SEVERITY_OPTIONS as readonly string[]).includes(severity)) {
    conditions.push(eq(conflicts.severity, severity as (typeof SEVERITY_OPTIONS)[number]));
  }

  const list = await db
    .select()
    .from(conflicts)
    .where(and(...conditions))
    .orderBy(desc(conflicts.detectedAt));

  function hrefFor(nextStatus?: string, nextSeverity?: string) {
    const qs = new URLSearchParams();
    if (nextStatus) qs.set("status", nextStatus);
    if (nextSeverity) qs.set("severity", nextSeverity);
    const query = qs.toString();
    return `/w/${orgId}/conflicts${query ? `?${query}` : ""}`;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs uppercase tracking-wide text-slate-500">Status</span>
        <FilterPill href={hrefFor(undefined, severity)} active={!status} label="All" />
        {STATUS_OPTIONS.map((s) => (
          <FilterPill key={s} href={hrefFor(s, severity)} active={status === s} label={formatLabel(s)} />
        ))}
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs uppercase tracking-wide text-slate-500">Severity</span>
        <FilterPill href={hrefFor(status, undefined)} active={!severity} label="All" />
        {SEVERITY_OPTIONS.map((s) => (
          <FilterPill key={s} href={hrefFor(status, s)} active={severity === s} label={formatLabel(s)} />
        ))}
      </div>

      <div className="space-y-3">
        {list.map((c) => (
          <Link
            key={c.id}
            href={`/w/${orgId}/conflicts/${c.id}`}
            className="block rounded-2xl border border-white/10 bg-white/[0.02] p-4 transition hover:bg-white/[0.05]"
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="font-medium text-white">{c.title}</p>
              <div className="flex gap-2">
                <span className={`rounded-full border px-2 py-0.5 text-[11px] uppercase ${severityClasses[c.severity]}`}>
                  {c.severity}
                </span>
                <span className={`rounded-full border px-2 py-0.5 text-[11px] ${statusClasses[c.status]}`}>
                  {formatLabel(c.status)}
                </span>
              </div>
            </div>
            {c.summary ? <p className="mt-2 text-sm text-slate-400">{c.summary}</p> : null}
            <p className="mt-2 text-xs text-slate-500">Detected {new Date(c.detectedAt).toLocaleString()}</p>
          </Link>
        ))}
        {list.length === 0 ? (
          <p className="rounded-2xl border border-dashed border-white/10 p-6 text-center text-sm text-slate-500">
            No conflicts match these filters.
          </p>
        ) : null}
      </div>
    </div>
  );
}

function FilterPill({ href, active, label }: { href: string; active: boolean; label: string }) {
  return (
    <Link
      href={href}
      className={`rounded-full border px-3 py-1 text-xs font-medium transition ${
        active
          ? "border-indigo-400/50 bg-indigo-500/20 text-indigo-200"
          : "border-white/10 bg-white/[0.02] text-slate-400 hover:text-slate-200"
      }`}
    >
      {label}
    </Link>
  );
}
