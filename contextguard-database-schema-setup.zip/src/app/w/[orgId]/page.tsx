import Link from "next/link";
import { db } from "@/db";
import { conflicts, documents } from "@/db/schema";
import { and, desc, eq, ne } from "drizzle-orm";
import { requireMembership } from "@/lib/roles";
import { severityClasses, statusClasses, formatLabel } from "@/lib/badges";

export const dynamic = "force-dynamic";

export default async function WorkspaceOverviewPage({
  params,
}: {
  params: Promise<{ orgId: string }>;
}) {
  const { orgId } = await params;
  await requireMembership(orgId);

  const [docs, openConflicts, recentConflicts] = await Promise.all([
    db.select().from(documents).where(eq(documents.orgId, orgId)).orderBy(desc(documents.createdAt)),
    db
      .select()
      .from(conflicts)
      .where(and(eq(conflicts.orgId, orgId), ne(conflicts.status, "resolved"), ne(conflicts.status, "dismissed"))),
    db.select().from(conflicts).where(eq(conflicts.orgId, orgId)).orderBy(desc(conflicts.detectedAt)).limit(6),
  ]);

  const severityCounts: Record<string, number> = { low: 0, medium: 0, high: 0, critical: 0 };
  for (const c of openConflicts) severityCounts[c.severity] = (severityCounts[c.severity] ?? 0) + 1;

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <StatCard label="Documents" value={docs.length} />
        <StatCard label="Open conflicts" value={openConflicts.length} />
        <StatCard label="Critical" value={severityCounts.critical} accent="text-red-400" />
        <StatCard label="High" value={severityCounts.high} accent="text-orange-400" />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <section className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-white">Recent conflicts</h2>
            <Link href={`/w/${orgId}/conflicts`} className="text-xs font-medium text-indigo-400 hover:text-indigo-300">
              View all
            </Link>
          </div>
          <div className="mt-4 space-y-3">
            {recentConflicts.length === 0 ? (
              <p className="text-sm text-slate-500">
                No conflicts detected yet. Upload at least two documents that discuss the same topic.
              </p>
            ) : (
              recentConflicts.map((c) => (
                <Link
                  key={c.id}
                  href={`/w/${orgId}/conflicts/${c.id}`}
                  className="block rounded-xl border border-white/10 bg-white/[0.02] p-3 transition hover:bg-white/[0.05]"
                >
                  <div className="flex items-center justify-between gap-2">
                    <p className="line-clamp-1 text-sm font-medium text-white">{c.title}</p>
                    <span className={`shrink-0 rounded-full border px-2 py-0.5 text-[10px] uppercase ${severityClasses[c.severity]}`}>
                      {c.severity}
                    </span>
                  </div>
                  <span className={`mt-2 inline-block rounded-full border px-2 py-0.5 text-[10px] ${statusClasses[c.status]}`}>
                    {formatLabel(c.status)}
                  </span>
                </Link>
              ))
            )}
          </div>
        </section>

        <section className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-white">Recent documents</h2>
            <Link href={`/w/${orgId}/documents`} className="text-xs font-medium text-indigo-400 hover:text-indigo-300">
              View all
            </Link>
          </div>
          <div className="mt-4 space-y-3">
            {docs.length === 0 ? (
              <p className="text-sm text-slate-500">No documents yet. Add your first one to get started.</p>
            ) : (
              docs.slice(0, 6).map((d) => (
                <Link
                  key={d.id}
                  href={`/w/${orgId}/documents/${d.id}`}
                  className="flex items-center justify-between rounded-xl border border-white/10 bg-white/[0.02] p-3 transition hover:bg-white/[0.05]"
                >
                  <p className="line-clamp-1 text-sm font-medium text-white">{d.title}</p>
                  <span className="shrink-0 text-xs text-slate-500">{d.status}</span>
                </Link>
              ))
            )}
          </div>
        </section>
      </div>
    </div>
  );
}

function StatCard({ label, value, accent }: { label: string; value: number; accent?: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
      <p className="text-xs uppercase tracking-wide text-slate-500">{label}</p>
      <p className={`mt-2 text-2xl font-semibold ${accent ?? "text-white"}`}>{value}</p>
    </div>
  );
}
