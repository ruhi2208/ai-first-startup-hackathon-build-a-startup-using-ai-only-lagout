import { db } from "@/db";
import { memberships, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireMembership } from "@/lib/roles";
import { changeMemberRoleAction, inviteMemberAction, removeMemberAction } from "../actions";

export const dynamic = "force-dynamic";

const ROLES = ["owner", "admin", "member", "viewer"] as const;

export default async function MembersPage({
  params,
  searchParams,
}: {
  params: Promise<{ orgId: string }>;
  searchParams: Promise<{ error?: string }>;
}) {
  const { orgId } = await params;
  const { role: myRole, user } = await requireMembership(orgId);
  const { error } = await searchParams;
  const canManage = myRole === "owner" || myRole === "admin";

  const members = await db
    .select({
      userId: memberships.userId,
      role: memberships.role,
      email: users.email,
      fullName: users.fullName,
      joinedAt: memberships.createdAt,
    })
    .from(memberships)
    .innerJoin(users, eq(memberships.userId, users.id))
    .where(eq(memberships.orgId, orgId))
    .orderBy(memberships.createdAt);

  return (
    <div className="space-y-8">
      {canManage ? (
        <section className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
          <h2 className="text-sm font-semibold text-white">Invite a teammate</h2>
          <p className="mt-1 text-xs text-slate-400">
            They need an existing ContextGuard account. Ask them to sign up, then invite them by email.
          </p>
          {error ? (
            <p className="mt-3 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-300">
              {error}
            </p>
          ) : null}
          <form action={inviteMemberAction} className="mt-4 flex flex-col gap-2 sm:flex-row">
            <input type="hidden" name="orgId" value={orgId} />
            <input
              type="email"
              name="email"
              required
              placeholder="teammate@company.com"
              className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2 text-sm text-white outline-none ring-indigo-500 placeholder:text-slate-500 focus:ring-2"
            />
            <select
              name="role"
              defaultValue="member"
              className="rounded-lg border border-white/10 bg-slate-900 px-3 py-2 text-sm text-white outline-none ring-indigo-500 focus:ring-2"
            >
              {ROLES.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
            <button
              type="submit"
              className="shrink-0 rounded-lg bg-indigo-500 px-4 py-2 text-sm font-semibold text-white transition hover:bg-indigo-400"
            >
              Invite
            </button>
          </form>
        </section>
      ) : null}

      <section>
        <h2 className="text-sm font-semibold text-white">Members</h2>
        <div className="mt-4 overflow-hidden rounded-2xl border border-white/10">
          <table className="w-full text-left text-sm">
            <thead className="bg-white/[0.03] text-xs uppercase tracking-wide text-slate-500">
              <tr>
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Email</th>
                <th className="px-4 py-3">Role</th>
                {canManage ? <th className="px-4 py-3" /> : null}
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {members.map((m) => (
                <tr key={m.userId} className="transition hover:bg-white/[0.03]">
                  <td className="px-4 py-3 text-white">{m.fullName ?? "—"}</td>
                  <td className="px-4 py-3 text-slate-400">{m.email}</td>
                  <td className="px-4 py-3">
                    {canManage ? (
                      <form action={changeMemberRoleAction} className="inline-flex items-center gap-2">
                        <input type="hidden" name="orgId" value={orgId} />
                        <input type="hidden" name="userId" value={m.userId} />
                        <select
                          name="role"
                          defaultValue={m.role}
                          className="rounded-lg border border-white/10 bg-slate-900 px-2 py-1 text-xs text-white outline-none ring-indigo-500 focus:ring-2"
                        >
                          {ROLES.map((r) => (
                            <option key={r} value={r}>
                              {r}
                            </option>
                          ))}
                        </select>
                        <button
                          type="submit"
                          className="rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-xs text-slate-300 transition hover:bg-white/10"
                        >
                          Update
                        </button>
                      </form>
                    ) : (
                      <span className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[11px] uppercase text-slate-400">
                        {m.role}
                      </span>
                    )}
                  </td>
                  {canManage ? (
                    <td className="px-4 py-3 text-right">
                      {m.userId !== user.id ? (
                        <form action={removeMemberAction}>
                          <input type="hidden" name="orgId" value={orgId} />
                          <input type="hidden" name="userId" value={m.userId} />
                          <button
                            type="submit"
                            className="rounded-lg border border-red-500/30 bg-red-500/10 px-2 py-1 text-xs text-red-300 transition hover:bg-red-500/20"
                          >
                            Remove
                          </button>
                        </form>
                      ) : null}
                    </td>
                  ) : null}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
