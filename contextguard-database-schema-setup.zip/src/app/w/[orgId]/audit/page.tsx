import { redirect } from "next/navigation";
import { db } from "@/db";
import { auditLog, users } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { requireMembership } from "@/lib/roles";

export const dynamic = "force-dynamic";

export default async function AuditLogPage({ params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  const { role } = await requireMembership(orgId);
  if (!(role === "owner" || role === "admin")) {
    redirect(`/w/${orgId}`);
  }

  const entries = await db
    .select({ entry: auditLog, actor: users })
    .from(auditLog)
    .leftJoin(users, eq(auditLog.actorId, users.id))
    .where(eq(auditLog.orgId, orgId))
    .orderBy(desc(auditLog.createdAt))
    .limit(200);

  const actionClasses: Record<string, string> = {
    INSERT: "border-emerald-500/30 bg-emerald-500/10 text-emerald-300",
    UPDATE: "border-amber-500/30 bg-amber-500/10 text-amber-300",
    DELETE: "border-red-500/30 bg-red-500/10 text-red-300",
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-sm font-semibold text-white">Audit log</h1>
        <p className="mt-1 text-xs text-slate-400">
          Append-only record of every create, update, and delete in this workspace.
        </p>
      </div>
      <div className="overflow-hidden rounded-2xl border border-white/10">
        <table className="w-full text-left text-sm">
          <thead className="bg-white/[0.03] text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-4 py-3">When</th>
              <th className="px-4 py-3">Actor</th>
              <th className="px-4 py-3">Action</th>
              <th className="px-4 py-3">Entity</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {entries.map((row) => (
              <tr key={row.entry.id} className="transition hover:bg-white/[0.03]">
                <td className="px-4 py-3 text-slate-400">{new Date(row.entry.createdAt).toLocaleString()}</td>
                <td className="px-4 py-3 text-white">{row.actor?.fullName ?? row.actor?.email ?? "system"}</td>
                <td className="px-4 py-3">
                  <span className={`rounded-full border px-2 py-0.5 text-[11px] ${actionClasses[row.entry.action] ?? ""}`}>
                    {row.entry.action}
                  </span>
                </td>
                <td className="px-4 py-3 text-slate-400">
                  {row.entry.entityType}
                  {row.entry.entityId ? ` · ${row.entry.entityId.slice(0, 8)}` : ""}
                </td>
              </tr>
            ))}
            {entries.length === 0 ? (
              <tr>
                <td colSpan={4} className="px-4 py-6 text-center text-slate-500">
                  No activity recorded yet.
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </div>
  );
}
