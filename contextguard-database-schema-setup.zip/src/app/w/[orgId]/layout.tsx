import type { ReactNode } from "react";
import { requireMembership } from "@/lib/roles";
import { TopNav } from "@/components/TopNav";
import { WorkspaceNav } from "@/components/WorkspaceNav";
import { SearchBar } from "@/components/SearchBar";

export default async function WorkspaceLayout({
  children,
  params,
}: {
  children: ReactNode;
  params: Promise<{ orgId: string }>;
}) {
  const { orgId } = await params;
  const { user, role, org } = await requireMembership(orgId);
  const isAdmin = role === "owner" || role === "admin";

  return (
    <main className="min-h-screen bg-slate-950">
      <TopNav user={user} right={<SearchBar orgId={orgId} />} />
      <div className="border-b border-white/10 bg-white/[0.02] px-6 py-4">
        <div className="mx-auto max-w-6xl">
          <p className="text-xs uppercase tracking-wide text-slate-500">Workspace</p>
          <h1 className="text-lg font-semibold text-white">{org.name}</h1>
        </div>
      </div>
      <div className="mx-auto max-w-6xl">
        <WorkspaceNav orgId={orgId} isAdmin={isAdmin} />
      </div>
      <div className="mx-auto max-w-6xl px-6 py-8">{children}</div>
    </main>
  );
}
