import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { conflictEvidence, conflicts, documentChunks, documents } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireMembership } from "@/lib/roles";
import { documentStatusClasses, severityClasses } from "@/lib/badges";
import { deleteDocumentAction } from "../../actions";

export const dynamic = "force-dynamic";

export default async function DocumentDetailPage({
  params,
}: {
  params: Promise<{ orgId: string; docId: string }>;
}) {
  const { orgId, docId } = await params;
  const { role } = await requireMembership(orgId);
  const canDelete = role === "owner" || role === "admin";

  const [doc] = await db.select().from(documents).where(eq(documents.id, docId)).limit(1);
  if (!doc || doc.orgId !== orgId) notFound();

  const chunks = await db
    .select()
    .from(documentChunks)
    .where(eq(documentChunks.documentId, docId))
    .orderBy(documentChunks.chunkIndex);

  const relatedConflicts = await db
    .select({ conflict: conflicts })
    .from(conflictEvidence)
    .innerJoin(conflicts, eq(conflictEvidence.conflictId, conflicts.id))
    .where(eq(conflictEvidence.documentId, docId));

  const uniqueConflicts = [...new Map(relatedConflicts.map((r) => [r.conflict.id, r.conflict])).values()];

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <Link href={`/w/${orgId}/documents`} className="text-xs text-slate-500 hover:text-slate-300">
            ← Back to documents
          </Link>
          <h1 className="mt-1 text-xl font-semibold text-white">{doc.title}</h1>
          <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-slate-400">
            <span className={`rounded-full border px-2 py-0.5 ${documentStatusClasses[doc.status]}`}>{doc.status}</span>
            <span>{doc.source}</span>
            <span>{chunks.length} chunks</span>
            <span>Added {new Date(doc.createdAt).toLocaleString()}</span>
          </div>
          {doc.errorMessage ? <p className="mt-2 text-xs text-red-400">{doc.errorMessage}</p> : null}
        </div>
        {canDelete ? (
          <form action={deleteDocumentAction}>
            <input type="hidden" name="orgId" value={orgId} />
            <input type="hidden" name="documentId" value={doc.id} />
            <button
              type="submit"
              className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-1.5 text-xs font-medium text-red-300 transition hover:bg-red-500/20"
            >
              Delete document
            </button>
          </form>
        ) : null}
      </div>

      {uniqueConflicts.length > 0 ? (
        <section>
          <h2 className="text-sm font-semibold text-white">Conflicts involving this document</h2>
          <div className="mt-3 space-y-2">
            {uniqueConflicts.map((c) => (
              <Link
                key={c.id}
                href={`/w/${orgId}/conflicts/${c.id}`}
                className="flex items-center justify-between rounded-xl border border-white/10 bg-white/[0.02] p-3 transition hover:bg-white/[0.05]"
              >
                <span className="text-sm text-white">{c.title}</span>
                <span className={`rounded-full border px-2 py-0.5 text-[10px] uppercase ${severityClasses[c.severity]}`}>
                  {c.severity}
                </span>
              </Link>
            ))}
          </div>
        </section>
      ) : null}

      <section>
        <h2 className="text-sm font-semibold text-white">Document content</h2>
        <div className="mt-3 space-y-3">
          {chunks.map((chunk) => (
            <div key={chunk.id} className="rounded-xl border border-white/10 bg-white/[0.02] p-4">
              <p className="mb-2 text-[11px] uppercase tracking-wide text-slate-500">
                Chunk {chunk.chunkIndex + 1}
              </p>
              <p className="whitespace-pre-wrap text-sm text-slate-300">{chunk.content}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
