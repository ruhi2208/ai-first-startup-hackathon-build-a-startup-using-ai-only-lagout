import Link from "next/link";
import { db } from "@/db";
import { documents } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { requireMembership } from "@/lib/roles";
import { documentStatusClasses } from "@/lib/badges";
import { uploadDocumentAction } from "../actions";

export const dynamic = "force-dynamic";

export default async function DocumentsPage({
  params,
  searchParams,
}: {
  params: Promise<{ orgId: string }>;
  searchParams: Promise<{ error?: string }>;
}) {
  const { orgId } = await params;
  const { role } = await requireMembership(orgId);
  const { error } = await searchParams;
  const canWrite = role === "owner" || role === "admin" || role === "member";

  const docs = await db
    .select()
    .from(documents)
    .where(eq(documents.orgId, orgId))
    .orderBy(desc(documents.createdAt));

  return (
    <div className="space-y-8">
      {canWrite ? (
        <section className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
          <h2 className="text-sm font-semibold text-white">Add a document</h2>
          <p className="mt-1 text-xs text-slate-400">
            Paste text or upload a .txt/.md file. ContextGuard will chunk it and automatically check
            it against every other document in this workspace.
          </p>
          {error ? (
            <p className="mt-3 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-300">
              {error}
            </p>
          ) : null}
          <form action={uploadDocumentAction} className="mt-4 space-y-3" encType="multipart/form-data">
            <input type="hidden" name="orgId" value={orgId} />
            <input
              type="text"
              name="title"
              required
              placeholder="Document title, e.g. Refund Policy v2"
              className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2 text-sm text-white outline-none ring-indigo-500 placeholder:text-slate-500 focus:ring-2"
            />
            <textarea
              name="content"
              rows={6}
              placeholder="Paste the document text here..."
              className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2 text-sm text-white outline-none ring-indigo-500 placeholder:text-slate-500 focus:ring-2"
            />
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <input
                type="file"
                name="file"
                accept=".txt,.md,text/plain,text/markdown"
                className="text-xs text-slate-400 file:mr-3 file:rounded-lg file:border-0 file:bg-white/10 file:px-3 file:py-1.5 file:text-xs file:text-white"
              />
              <button
                type="submit"
                className="rounded-lg bg-indigo-500 px-4 py-2 text-sm font-semibold text-white transition hover:bg-indigo-400"
              >
                Upload &amp; analyze
              </button>
            </div>
          </form>
        </section>
      ) : null}

      <section>
        <h2 className="text-sm font-semibold text-white">All documents</h2>
        <div className="mt-4 overflow-hidden rounded-2xl border border-white/10">
          <table className="w-full text-left text-sm">
            <thead className="bg-white/[0.03] text-xs uppercase tracking-wide text-slate-500">
              <tr>
                <th className="px-4 py-3">Title</th>
                <th className="px-4 py-3">Source</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Added</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {docs.map((d) => (
                <tr key={d.id} className="transition hover:bg-white/[0.03]">
                  <td className="px-4 py-3">
                    <Link href={`/w/${orgId}/documents/${d.id}`} className="font-medium text-white hover:text-indigo-300">
                      {d.title}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-slate-400">{d.source}</td>
                  <td className="px-4 py-3">
                    <span className={`rounded-full border px-2 py-0.5 text-[11px] ${documentStatusClasses[d.status]}`}>
                      {d.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-slate-400">{new Date(d.createdAt).toLocaleString()}</td>
                </tr>
              ))}
              {docs.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-4 py-6 text-center text-slate-500">
                    No documents uploaded yet.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
