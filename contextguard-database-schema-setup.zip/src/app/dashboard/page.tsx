import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { conflicts, documents, memberships, organizations } from "@/db/schema";
import { and, eq, count, ne } from "drizzle-orm";
import { createWorkspaceAction } from "./actions";
import { TopNav } from "@/components/TopNav";

export const dynamic = "force-dynamic";

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const { error } = await searchParams;

  const orgs = await db
    .select({
      id: organizations.id,
      name: organizations.name,
      role: memberships.role,
      createdAt: organizations.createdAt,
    })
    .from(memberships)
    .innerJoin(organizations, eq(memberships.orgId, organizations.id))
    .where(eq(memberships.userId, user.id))
    .orderBy(organizations.createdAt);

  const stats = await Promise.all(
    orgs.map(async (org) => {
      const [[docCount], [openConflicts]] = await Promise.all([
        db.select({ value: count() }).from(documents).where(eq(documents.orgId, org.id)),
        db
          .select({ value: count() })
          .from(conflicts)
          .where(and(eq(conflicts.orgId, org.id), ne(conflicts.status, "resolved"))),
      ]);
      return { orgId: org.id, docs: docCount.value, openConflicts: openConflicts.value };
    }),
  );

  const statMap = new Map(stats.map((s) => [s.orgId, s]));

  return (
    <main className="min-h-screen bg-slate-950">
      <TopNav user={user} />
      <div className="mx-auto max-w-5xl px-6 py-10">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-white">Your workspaces</h1>
            <p className="mt-1 text-sm text-slate-400">
              Each workspace has its own documents, detected conflicts, and audit trail.
            </p>
          </div>
        </div>

        {error ? (
          <p className="mt-4 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-300">
            {error}
          </p>
        ) : null}

        <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
          {orgs.map((org) => {
            const s = statMap.get(org.id);
            return (
              <Link
                key={org.id}
                href={`/w/${org.id}`}
                className="group rounded-2xl border border-white/10 bg-white/[0.03] p-5 transition hover:bg-white/[0.06]"
              >
                <div className="flex items-start justify-between">
                  <h2 className="text-base font-semibold text-white group-hover:text-indigo-300">
                    {org.name}
                  </h2>
                  <span className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[11px] uppercase tracking-wide text-slate-400">
                    {org.role}
                  </span>
                </div>
                <div className="mt-4 flex gap-4 text-xs text-slate-400">
                  <span>{s?.docs ?? 0} documents</span>
                  <span>{s?.openConflicts ?? 0} open conflicts</span>
                </div>
              </Link>
            );
          })}

          <form
            action={createWorkspaceAction}
            className="flex flex-col justify-between rounded-2xl border border-dashed border-white/15 bg-white/[0.02] p-5"
          >
            <div>
              <h2 className="text-base font-semibold text-white">Create a workspace</h2>
              <p className="mt-1 text-xs text-slate-400">
                Spin up a new space for a team, product, or client.
              </p>
            </div>
            <div className="mt-4 flex gap-2">
              <input
                type="text"
                name="name"
                required
                placeholder="Workspace name"
                className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2 text-sm text-white outline-none ring-indigo-500 placeholder:text-slate-500 focus:ring-2"
              />
              <button
                type="submit"
                className="shrink-0 rounded-lg bg-indigo-500 px-4 py-2 text-sm font-semibold text-white transition hover:bg-indigo-400"
              >
                Create
              </button>
            </div>
          </form>
        </div>
      </div>
    </main>
  );
}
