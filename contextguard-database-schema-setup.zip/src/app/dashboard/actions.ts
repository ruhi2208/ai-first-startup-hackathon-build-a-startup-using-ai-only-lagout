"use server";

import { redirect } from "next/navigation";
import { db } from "@/db";
import { memberships, organizations } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export async function createWorkspaceAction(formData: FormData) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const name = String(formData.get("name") || "").trim();
  if (!name) {
    redirect(`/dashboard?error=${encodeURIComponent("Workspace name is required.")}`);
  }

  const orgId = await db.transaction(async (tx) => {
    const [org] = await tx
      .insert(organizations)
      .values({ name, createdBy: user!.id })
      .returning({ id: organizations.id });
    await tx.insert(memberships).values({ orgId: org.id, userId: user!.id, role: "owner" });
    return org.id;
  });

  redirect(`/w/${orgId}`);
}
