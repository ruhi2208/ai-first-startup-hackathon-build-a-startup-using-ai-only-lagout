"use server";

import { redirect } from "next/navigation";
import { db } from "@/db";
import { memberships, organizations, users } from "@/db/schema";
import { hashPassword } from "@/lib/password";
import { createSession } from "@/lib/auth";
import { eq } from "drizzle-orm";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function signupAction(formData: FormData) {
  const fullName = String(formData.get("fullName") || "").trim();
  const email = String(formData.get("email") || "")
    .trim()
    .toLowerCase();
  const password = String(formData.get("password") || "");

  if (!fullName || fullName.length < 2) {
    redirect(`/signup?error=${encodeURIComponent("Please enter your full name.")}`);
  }
  if (!EMAIL_RE.test(email)) {
    redirect(`/signup?error=${encodeURIComponent("Please enter a valid email address.")}`);
  }
  if (password.length < 8) {
    redirect(`/signup?error=${encodeURIComponent("Password must be at least 8 characters.")}`);
  }

  const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
  if (existing.length > 0) {
    redirect(`/signup?error=${encodeURIComponent("An account with that email already exists.")}`);
  }

  const passwordHash = hashPassword(password);

  const newUserId = await db.transaction(async (tx) => {
    const [user] = await tx
      .insert(users)
      .values({ email, passwordHash, fullName })
      .returning({ id: users.id });

    const [org] = await tx
      .insert(organizations)
      .values({ name: `${fullName}'s workspace`, createdBy: user.id })
      .returning({ id: organizations.id });

    await tx.insert(memberships).values({ orgId: org.id, userId: user.id, role: "owner" });

    return user.id;
  });

  await createSession(newUserId);
  redirect("/dashboard");
}
