"use client";

export function SearchBar({ orgId }: { orgId: string }) {
  return (
    <form action={`/w/${orgId}/search`} method="GET" className="hidden sm:block">
      <input
        type="text"
        name="q"
        placeholder="Search documents and conflicts"
        className="w-64 rounded-lg border border-white/10 bg-slate-900 px-3 py-1.5 text-sm text-white outline-none ring-indigo-500 placeholder:text-slate-500 focus:ring-2"
      />
    </form>
  );
}
