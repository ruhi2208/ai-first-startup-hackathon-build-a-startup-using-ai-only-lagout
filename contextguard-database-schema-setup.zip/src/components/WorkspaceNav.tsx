"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

export function WorkspaceNav({ orgId, isAdmin }: { orgId: string; isAdmin: boolean }) {
  const pathname = usePathname();

  const tabs = [
    { href: `/w/${orgId}`, label: "Overview", exact: true },
    { href: `/w/${orgId}/documents`, label: "Documents" },
    { href: `/w/${orgId}/conflicts`, label: "Conflicts" },
    { href: `/w/${orgId}/members`, label: "Members" },
    ...(isAdmin ? [{ href: `/w/${orgId}/audit`, label: "Audit log" }] : []),
  ];

  return (
    <nav className="flex gap-1 overflow-x-auto border-b border-white/10 px-6">
      {tabs.map((tab) => {
        const active = tab.exact ? pathname === tab.href : pathname?.startsWith(tab.href);
        return (
          <Link
            key={tab.href}
            href={tab.href}
            className={`whitespace-nowrap border-b-2 px-3 py-3 text-sm font-medium transition ${
              active
                ? "border-indigo-400 text-white"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            {tab.label}
          </Link>
        );
      })}
    </nav>
  );
}
