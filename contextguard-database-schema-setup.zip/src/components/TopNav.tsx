import Link from "next/link";
import { ShieldLogo } from "@/components/ShieldLogo";
import { logoutAction } from "@/app/login/actions";
import type { SessionUser } from "@/lib/auth";

export function TopNav({ user, right }: { user: SessionUser; right?: React.ReactNode }) {
  return (
    <header className="sticky top-0 z-20 border-b border-white/10 bg-slate-950/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <Link href="/dashboard" className="flex items-center gap-2 text-white">
          <ShieldLogo className="h-6 w-6" />
          <span className="text-base font-semibold tracking-tight">ContextGuard</span>
        </Link>
        <div className="flex items-center gap-4">
          {right}
          <span className="hidden text-sm text-slate-400 sm:inline">{user.fullName ?? user.email}</span>
          <form action={logoutAction}>
            <button
              type="submit"
              className="rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-medium text-slate-300 transition hover:bg-white/10"
            >
              Sign out
            </button>
          </form>
        </div>
      </div>
    </header>
  );
}
