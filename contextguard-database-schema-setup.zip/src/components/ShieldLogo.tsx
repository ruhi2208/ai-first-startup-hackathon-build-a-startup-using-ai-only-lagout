export function ShieldLogo({ className = "h-6 w-6" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
      <path
        d="M12 2.5l7.5 3v5.4c0 4.9-3.2 9.3-7.5 10.6-4.3-1.3-7.5-5.7-7.5-10.6V5.5l7.5-3z"
        fill="url(#cg-grad)"
        stroke="url(#cg-grad-stroke)"
        strokeWidth="1"
      />
      <path
        d="M8.7 12.2l2.1 2.1 4.3-4.6"
        stroke="white"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <defs>
        <linearGradient id="cg-grad" x1="4" y1="2" x2="20" y2="22" gradientUnits="userSpaceOnUse">
          <stop stopColor="#6366f1" />
          <stop offset="1" stopColor="#8b5cf6" />
        </linearGradient>
        <linearGradient id="cg-grad-stroke" x1="4" y1="2" x2="20" y2="22" gradientUnits="userSpaceOnUse">
          <stop stopColor="#818cf8" />
          <stop offset="1" stopColor="#a78bfa" />
        </linearGradient>
      </defs>
    </svg>
  );
}
